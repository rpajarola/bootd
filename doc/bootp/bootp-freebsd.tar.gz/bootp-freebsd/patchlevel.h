/* 
 * patchlevel.h 
 *
 * $FreeBSD: src/libexec/bootpd/patchlevel.h,v 1.5 1999/08/28 00:09:19 peter Exp $
 */

#define VERSION 	"2.4"
#define PATCHLEVEL	3
